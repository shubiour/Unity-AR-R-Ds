﻿namespace GLTFast {

    public interface IDeferAgent {
        void Reset();
        bool ShouldDefer();
    }
}