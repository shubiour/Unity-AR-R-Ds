package com.xraph.plugin.flutter_unity_widget_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
