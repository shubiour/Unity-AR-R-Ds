//
//  FlutterUnityWidgetPlugin.h
//  FlutterUnityWidgetPlugin
//
//  Created by Kris Pypen on 8/1/19.
//  Updated by Rex Raphael on 8/27/2020.
//

#import <Flutter/Flutter.h>

@interface FlutterUnityWidgetPlugin : NSObject<FlutterPlugin>
@end

