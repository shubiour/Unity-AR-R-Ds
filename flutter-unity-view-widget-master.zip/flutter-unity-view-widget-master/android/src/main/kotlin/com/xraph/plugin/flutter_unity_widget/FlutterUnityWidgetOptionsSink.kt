package com.xraph.plugin.flutter_unity_widget

interface FlutterUnityWidgetOptionsSink {
    fun setFullscreenEnabled(fullscreenEnabled: Boolean)
}