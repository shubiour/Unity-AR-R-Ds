package com.xraph.plugin.flutter_unity_widget

class FlutterUnityWidgetOptions {
    var fullscreenEnabled: Boolean = false
}