package com.xraph.plugin.flutter_unity_widget

interface OnCreateUnityViewCallback {
    fun onReady()
}